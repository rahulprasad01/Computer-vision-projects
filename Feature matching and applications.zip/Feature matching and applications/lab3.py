""" CS4243 Lab 3: Feature Matching and Applications
"""
import numpy as np
from skimage import filters
from skimage.feature import corner_peaks
from scipy.spatial.distance import cdist
from scipy.ndimage.filters import convolve
from scipy.ndimage import gaussian_filter
from utils import pad, unpad
import math
import cv2
_COLOR_RED = (255, 0, 0)
_COLOR_GREEN = (0, 255, 0)
_COLOR_BLUE = (0, 0, 255)

_COLOR_RED = (255, 0, 0)
_COLOR_GREEN = (0, 255, 0)
_COLOR_BLUE = (0, 0, 255)



##### Part 1: Keypoint Detection, Description, and Matching #####

def harris_corners(img, window_size=3, k=0.04):

    H, W= img.shape
    window = np.ones((window_size, window_size))
    response = np.zeros((H, W))

    Ix = filters.sobel_v(img)
    Iy = filters.sobel_h(img)
    
    Ix2 = Ix * Ix
    Iy2 = Iy * Iy
    IxIy = Ix * Iy
    
    SumIx2 = convolve(Ix2, np.ones((window_size,window_size)))
    SumIy2 = convolve(Iy2, np.ones((window_size,window_size)))
    SumIxIy = convolve(IxIy, np.ones((window_size,window_size)))

    shape = SumIx2.shape
    response = np.zeros(shape)

    for row in range(shape[0]):
        for col in range(shape[1]):
            H = np.array([[SumIx2[row][col],SumIxIy[row][col]],[SumIxIy[row][col],SumIy2[row][col]]])
            response[row][col] = np.linalg.det(H) - k * (np.trace(H) ** 2)
    
    return response

def naive_descriptor(patch):
    
    feature = []
    
    mu = np.mean(patch)
    sigma = np.std(patch)
    norm = patch - mu / (sigma + 0.0001)
    norm = np.where(norm > 0, norm, 0)
    feature = np.ndarray.flatten(norm)

    return feature

# GIVEN
def describe_keypoints(image, keypoints, desc_func, patch_size=16):
    '''
    Args:
        image: grayscale image of shape (H, W)
        keypoints: 2D array containing a keypoint (x, y) in each row
        desc_func: function that takes in an image patch and outputs
            a 1D feature vector describing the patch
        patch_size: size of a square patch at each keypoint
                
    Returns:
        desc: array of features describing the keypoints
    '''

    image.astype(np.float32)
    desc = []
    for i, kp in enumerate(keypoints):
        y, x = kp
        patch = image[np.max([0,y-(patch_size//2)]):y+((patch_size+1)//2),
                      np.max([0,x-(patch_size//2)]):x+((patch_size+1)//2)]
      
        desc.append(desc_func(patch))
   
    return np.array(desc)

# GIVEN
def make_gaussian_kernel(ksize, sigma):
    '''
    Good old Gaussian kernel.
    :param ksize: int
    :param sigma: float
    :return kernel: numpy.ndarray of shape (ksize, ksize)
    '''

    ax = np.linspace(-(ksize - 1) / 2., (ksize - 1) / 2., ksize)
    yy, xx = np.meshgrid(ax, ax)

    kernel = np.exp(-0.5 * (np.square(yy) + np.square(xx)) / np.square(sigma))

    return kernel / kernel.sum()


def simple_sift(patch):
    
    
    # You can change the parameter sigma, which has been default to 3
    weights = np.flipud(np.fliplr(make_gaussian_kernel(patch.shape[0],3)))
    
    histogram = np.zeros((4,4,8))
    
    Ix = filters.sobel_v(patch)
    Iy = filters.sobel_h(patch)
    grad_magnitude = np.sqrt((Ix**2) + (Iy**2))
    grad_angle = np.arctan2(Iy,Ix) * 180/np.pi
    grad_magnitude = grad_magnitude * weights

    shape = patch.shape
    hist = []

    for i in range(shape[0]//4):
        for j in range(shape[1]//4):
            grad_window = grad_angle[i * 4: (i * 4) + 4, j * 4 : (j * 4) + 4]
            weight_window = grad_magnitude[i * 4: (i * 4) + 4, j * 4 : (j * 4) + 4]

            temp = np.zeros(8)

            for row in range(4):
                for col in range(4):
                    angle = grad_window[row][col]
                    weight = weight_window[row][col]

                    if 0 <= angle < 45:
                        temp[0] += weight
                    elif 45 <= angle < 90:
                        temp[1] += weight
                    elif 90 <= angle < 135:
                        temp[2] += weight
                    elif 135 <= angle <= 180:
                        temp[3] += weight
                    elif -45 <= angle < 0:
                        temp[7] += weight
                    elif -90 <= angle < -45:
                        temp[6] += weight
                    elif -135 <= angle < -90:
                        temp[5] += weight
                    elif -180 <= angle < -135:
                        temp[4] += weight
                        
            hist.append(temp)
    hist = np.array(hist)
    feature = hist.flatten()
    feature = feature / np.linalg.norm(feature)

    return feature

def top_k_matches(desc1, desc2, k=2):
    
    match_pairs = []
    
    difference = cdist(desc1, desc2)
    for i in range(len(difference)):
        dist = difference[i]
        sorted_dist = sorted(dist)[:k]
        temp_tup = (i , [])
        for j in sorted_dist:
            temp_tup[1].append((np.where(dist == j)[0], j))
        match_pairs.append(temp_tup)

    return match_pairs

def ratio_test_match(desc1, desc2, match_threshold):
    
    match_pairs = []
    top_2_matches = top_k_matches(desc1, desc2)
    
    for i in top_2_matches:
        if (i[1][0][1] / i[1][1][1])  < match_threshold:
            match_pairs.append([i[0], int(i[1][0][0])])

    match_pairs = np.array(match_pairs)
    return match_pairs

# GIVEN
def compute_cv2_descriptor(im, method=cv2.SIFT_create()):
    '''
    Detects and computes keypoints using one of the implementations in OpenCV
    You can use:
        cv2.SIFT_create()

    Do note that the keypoints coordinate is (col, row)-(x,y) in OpenCV. We have changed it to (row,col)-(y,x) for you. (Consistent with out coordinate choice)
    '''
    kpts, descs = method.detectAndCompute(im, None)
    
    keypoints = np.array([(kp.pt[1],kp.pt[0]) for kp in kpts])
    angles = np.array([kp.angle for kp in kpts])
    sizes = np.array([kp.size for kp in kpts])
    
    return keypoints, descs, angles, sizes

##### Part 2: Image Stitching #####

# GIVEN
def transform_homography(src, h_matrix, getNormalized = True):
    '''
    Performs the perspective transformation of coordinates

    Args:
        src (np.ndarray): Coordinates of points to transform (N,2)
        h_matrix (np.ndarray): Homography matrix (3,3)

    Returns:
        transformed (np.ndarray): Transformed coordinates (N,2)

    '''
    transformed = None

    input_pts = np.insert(src, 2, values=1, axis=1)
    transformed = np.zeros_like(input_pts)
    transformed = h_matrix.dot(input_pts.transpose())
    if getNormalized:
        transformed = transformed[:-1]/transformed[-1]
    transformed = transformed.transpose().astype(np.float32)
    
    return transformed


def compute_homography(src, dst):
   
    h_matrix = np.eye(3, dtype=np.float64)
  
    num_points = src.shape[0]
    src_x = src[:, 0]
    src_y = src[:, 1]
    dst_x = dst[:, 0]
    dst_y = dst[:, 1]

    # Normalization matrix: Translate by mean vector & scale by SD/sqrt(2)
    src_meanx = np.mean(src_x)
    src_meany = np.mean(src_y)
    src_stdx = np.std(src_x) / np.sqrt(2)
    src_stdy = np.std(src_y) / np.sqrt(2)
    T_src = np.array([[1/src_stdx, 0, -src_meanx/src_stdx], [0, 1/src_stdy, -src_meany/src_stdy], [0, 0, 1]])

    dst_meanx = np.mean(dst_x)
    dst_meany = np.mean(dst_y)
    dst_stdx = np.std(dst_x) / np.sqrt(2)
    dst_stdy = np.std(dst_y) / np.sqrt(2)
    T_dst = np.array([[1/dst_stdx, 0, -dst_meanx/dst_stdx], [0, 1/dst_stdy, -dst_meany/dst_stdy], [0, 0, 1]])

    # Normalize src and dst
    src_norm = transform_homography(src, T_src)
    dst_norm = transform_homography(dst, T_dst)

    # DLT
    A = []
    for i in range(num_points):
        x = src_norm[i, 0]
        y = src_norm[i, 1]
        x_p = dst_norm[i, 0]
        y_p = dst_norm[i, 1]
        A.append([-x, -y, -1, 0, 0, 0, x*x_p, y*x_p, x_p]) 
        A.append([0, 0, 0, -x, -y, -1, x*y_p, y*y_p, y_p])

    A = np.array(A)
    u, s, vh = np.linalg.svd(A)
    H = (vh[-1,:]/ vh[-1,-1]).reshape((3,3))

    # Denormalization: Revert initial transformations
    h_matrix = np.matmul(np.linalg.inv(T_dst), np.matmul(H, T_src))

    return h_matrix

def ransac_homography(keypoints1, keypoints2, matches, sampling_ratio=0.5, n_iters=500, delta=20):
    
    N = matches.shape[0]
    n_samples = int(N * sampling_ratio)

    matched1_unpad = keypoints1[matches[:,0]]
    matched2_unpad = keypoints2[matches[:,1]]

    max_inliers = np.zeros(N)
    n_inliers = 0

    
    H = np.eye(3, dtype=np.float64)
    for i in range(n_iters):
        curr_inliers = []
        num_inliers = 0

        
        indices = np.random.randint(N, size=n_samples)
        samples = matches[indices]
        src = keypoints1[samples[:, 0]]
        dst = keypoints2[samples[:, 1]]
        H_temp = compute_homography(src, dst)

        
        for i in indices:
            P = np.array([keypoints1[matches[i][0]][0], keypoints1[matches[i][0]][1], 1])
            P_match = keypoints2[matches[i][1]]
            P_result = np.matmul(H_temp, P)
            P_proj = np.array([P_result[0], P_result[1]])
            if np.linalg.norm(P_match - P_proj) <= delta:
                num_inliers += 1
                curr_inliers.append(i)

            if num_inliers > n_inliers:
                n_inliers = num_inliers
                H = H_temp
                max_inliers = np.array(curr_inliers)
    
   
    inliers_val = matches[max_inliers]
    result_src = keypoints1[inliers_val[:, 0]]
    result_dst = keypoints2[inliers_val[:, 1]]
    H = compute_homography(result_src, result_dst)
    
    return H, matches[max_inliers]

##### Part 3: Mirror Symmetry Detection #####

# GIVEN 
from skimage.feature import peak_local_max
def find_peak_params(hspace, params_list,  window_size=1, threshold=0.5):
    '''
    Given a Hough space and a list of parameters range, compute the local peaks
    aka bins whose count is larger max_bin * threshold. The local peaks are computed
    over a space of size (2*window_size+1)^(number of parameters)

    Also include the array of values corresponding to the bins, in descending order.
    '''
    assert len(hspace.shape) == len(params_list), \
        "The Hough space dimension does not match the number of parameters"
    for i in range(len(params_list)):
        assert hspace.shape[i] == len(params_list[i]), \
            f"Parameter length does not match size of the corresponding dimension:{len(params_list[i])} vs {hspace.shape[i]}"
    peaks_indices = peak_local_max(hspace.copy(), exclude_border=False, threshold_rel=threshold, min_distance=window_size)
    peak_values = np.array([hspace[tuple(peaks_indices[j])] for j in range(len(peaks_indices))])
    res = []
    res.append(peak_values)
    for i in range(len(params_list)):
        res.append(params_list[i][peaks_indices.T[i]])
    return res

# GIVEN
def angle_with_x_axis(pi, pj):  
    '''
    Compute the angle that the line connecting two points I and J make with the x-axis (mind our coordinate convention)
    Do note that the line direction is from point I to point J.
    '''
    # get the difference between point p1 and p2
    y, x = pi[0]-pj[0], pi[1]-pj[1] 
    
    if x == 0:
        return np.pi/2  
    
    angle = np.arctan(y/x)
    if angle < 0:
        angle += np.pi
    return angle

# GIVEN
def midpoint(pi, pj):
    '''
    Get y and x coordinates of the midpoint of I and J
    '''
    return (pi[0]+pj[0])/2, (pi[1]+pj[1])/2

# GIVEN
def distance(pi, pj):
    '''
    Compute the Euclidean distance between two points I and J.
    '''
    y,x = pi[0]-pj[0], pi[1]-pj[1] 
    return np.sqrt(x**2+y**2)

def shift_sift_descriptor(desc):
    
    desc = desc.reshape((16, 8))
    num_hist = desc.shape[0]
    num_bins = desc.shape[1]
    hist_arr = np.zeros(desc.shape)
    for i in range(num_hist):
        hist_bins = np.zeros(num_bins)
        hist_bins[0] = desc[i, 0]
        hist_bins[1:] = np.flip(desc[i, 1:])
        hist_arr[i] = hist_bins
    
    res = np.zeros(desc.shape)
    j = 0
    while j < num_hist:
        res[-j-4] = hist_arr[j]
        res[-j-3] = hist_arr[j+1]
        res[-j-2] = hist_arr[j+2]
        res[-j-1] = hist_arr[j+3]
        j += 4
    res = res.reshape(128)
    
    return res

def create_mirror_descriptors(img):
    '''
    Return the output for compute_cv2_descriptor (which you can find in utils.py)
    Also return the set of virtual mirror descriptors.
    Make sure the virtual descriptors correspond to the original set of descriptors.
    '''
    
    kps, descs, sizes, angles = compute_cv2_descriptor(img)
    mirror_descriptors = np.zeros((descs.shape))
    num_descs = descs.shape[0]
    for i in range(num_descs):
        mirror_descriptors[i] = shift_sift_descriptor(descs[i])
    
    return kps, descs, sizes, angles, mirror_descriptors

def match_mirror_descriptors(descs, mirror_descs, threshold = 0.7):
    
    three_matches = top_k_matches(descs, mirror_descs, k=3)

    match_result = []

    
    for match_set in three_matches:
        point = match_set[0]
        match_points = match_set[1]
        match1, match2, match3 = match_points[0][0][0], match_points[1][0][0], match_points[2][0][0]
        if point == match1:
            match_points = np.delete(match_points, 0, axis=0)
        elif point == match2:
            match_points = np.delete(match_points, 1, axis=0)
        elif point == match3:
            match_points = np.delete(match_points, 2, axis=0)
        
        m = list(match_points)
        m.sort(key=lambda x : x[1])
        
        top_two = np.array([m[0][0][0], m[1][0][0]])
        if m[0][1] / m[1][1] < threshold:
            match_result.append([point, m[0][0][0]])
    match_result = np.array(match_result)
    
    return match_result


def find_symmetry_lines(matches, kps):
    
    rhos = []
    thetas = []
    
    num_matches = matches.shape[0]
    original_kps = kps[matches[:, 0]]
    mirror_kps = kps[matches[:, 1]]

    for i in range(num_matches):
        x_original, y_original = original_kps[i, 1], original_kps[i, 0]
        x_mirror, y_mirror = mirror_kps[i, 1], mirror_kps[i, 0]
        x_mid = (x_original + x_mirror) / 2
        y_mid = (y_original + y_mirror) / 2
        
        theta = angle_with_x_axis([y_original, x_original], [y_mirror, x_mirror])
        rho = x_mid * math.cos(theta) + y_mid * math.sin(theta)
        
        rhos.append(rho)
        thetas.append(theta)
    rhos = np.array(rhos)
    thetas = np.array(thetas)
    
    return rhos, thetas

def hough_vote_mirror(matches, kps, im_shape, window=1, threshold=0.5, num_lines=1):
    
    rhos, thetas = find_symmetry_lines(matches, kps)
    
    rho_interval = 1
    theta_interval = math.pi/180
    img_height, img_width = im_shape
    rho_max = math.ceil(math.sqrt(img_height**2 + img_width**2))
    rho_min = -rho_max
    theta_max = 2 * math.pi
    theta_min = 0

    
    rho_bin_num = math.ceil((rho_max - rho_min) / rho_interval)
    theta_bin_num = math.ceil((theta_max - theta_min) / theta_interval)
    A = np.zeros((rho_bin_num, theta_bin_num), int)
   
    rho_bins = np.arange(rho_min, rho_max, rho_interval)
    theta_bins = np.arange(theta_min, theta_max, theta_interval)

    
    for i in range(rhos.shape[0]):
        y = np.argmax(rho_bins > rhos[i])
        x = np.argmax(theta_bins > thetas[i])
        A[y, x] += 1
    
    params_list = [rho_bins, theta_bins]
    votes, peak_rhos, peak_thetas = find_peak_params(A, params_list, window, threshold)
    
    rho_values = peak_rhos[:num_lines]
    theta_values = peak_thetas[:num_lines]
    
    return rho_values, theta_values




"""Helper functions: You should not have to touch the following functions.
"""
def trim(frame):
    if not np.sum(frame[0]):
        return trim(frame[1:])
    if not np.sum(frame[-1]):
        return trim(frame[:-2])
    if not np.sum(frame[:,0]):
        return trim(frame[:,1:])
    if not np.sum(frame[:,-1]):
        return trim(frame[:,:-2])
    return frame