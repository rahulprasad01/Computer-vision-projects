""" CS4243 Lab 1: Template Matching
"""

import os
import cv2
import random
import numpy as np
import matplotlib.pyplot as plt
import math

##### Part 1: Image Preprossessing #####


def rgb2gray(img):
    
    if len(img.shape) != 3:
        print('RGB Image should have 3 channels')
        return
    
    height, width = img.shape[:2]
    grayscale = lambda pic: 0.299 * pic[0] + 0.587 * pic[1] + 0.114 * pic[2]
    gray_image = np.zeros(img.shape[:2])
    for h in range(height):
        for w in range(width):
            gray_image[h][w] = np.round(grayscale(img[h][w]))

    gray_image = gray_image.astype('uint8')

    return gray_image


def convolution(img, kernel, k):

    padded_image = pad_zeros(img, k, k, k, k)
    height, width = img.shape[:2]
    convolution_image = img.astype('float')
    for h in range(k, k + height):
        for w in range(k, k + width):
            new_pixel = 0.0
            for p in range(-k, k+1, 1):
                for r in range(-k, k+1, 1):
                    new_pixel += padded_image[h + p][w + r] * kernel[k - p][k - r]
            convolution_image[h - k][w - k] = new_pixel
    return convolution_image


def gray2grad(img):

   
    sobelh = np.array([[-1, 0, 1], 
                       [-2, 0, 2], 
                       [-1, 0, 1]], dtype = float)
    sobelv = np.array([[-1, -2, -1], 
                       [0, 0, 0], 
                       [1, 2, 1]], dtype = float)
    sobeld1 = np.array([[-2, -1, 0],
                        [-1, 0, 1],
                        [0,  1, 2]], dtype = float)
    sobeld2 = np.array([[0, -1, -2],
                        [1, 0, -1],
                        [2, 1, 0]], dtype = float)
    
    img_grad = img.astype('float')
    img_grad_h = convolution(img_grad, sobelh, 1)
    img_grad_v = convolution(img_grad, sobelv, 1)
    img_grad_d1 = convolution(img_grad, sobeld1, 1)
    img_grad_d2 = convolution(img_grad, sobeld2, 1)

    return img_grad_h, img_grad_v, img_grad_d1, img_grad_d2


def pad_zeros(img, pad_height_bef, pad_height_aft, pad_width_bef, pad_width_aft):
    
    height, width = img.shape[:2]
    new_height, new_width = (height + pad_height_bef + pad_height_aft), (width + pad_width_bef + pad_width_aft)
    image_padded = np.zeros((new_height, new_width)) if len(img.shape) == 2 else np.zeros((new_height, new_width, img.shape[2]))

    
    for h in range(height):
        for w in range(width):
             image_padded[h + pad_height_bef][w + pad_width_bef] = img[h][w]
    return image_padded.astype(img.dtype)

##### Part 2: Normalized Cross Correlation #####


def normalized_cross_correlation(img, template):
   
    Hi, Wi = img.shape[:2]
    Hk, Wk = template.shape[:2]
    Ho = Hi - Hk + 1
    Wo = Wi - Wk + 1

    image_float = img.astype('float')
    template_float = template.astype('float')

    kernel_magnitude = np.linalg.norm(template_float)
    response = np.zeros((Ho, Wo))

    # GREYSCALE

    if len(img.shape) == 2:
        for i in range(Ho):
            for j in range(Wo):
                covered_elements = image_float[i:i+Hk, j:j+Wk]
                covered_magnitude = np.linalg.norm(covered_elements)
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = 0.0

                for p in range(Hk):
                    for r in range(Wk):
                        neighbour = image_float[i+p, j+1]
                        filtered_value += (template_float[p, r] * neighbour)

                response[i, j] = norm_coefficient * filtered_value

    # RGB
    elif len(img.shape) == 3:
        for i in range(Ho):
            for j in range(Wo):
                covered_elements = image_float[i:i+Hk, j:j+Wk, :]
                covered_magnitude = np.linalg.norm(covered_elements)
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = 0.0

                for c in range(3):
                    for p in range(Hk):
                        for r in range(Wk):
                            neighbour =image_float[i+p, j+r, c]
                            filtered_value += (template_float[p, r, c] * neighbour)

                response[i, j] = norm_coefficient * filtered_value

    return response


def normalized_cross_correlation_fast(img, template):
   
    Hi, Wi = img.shape[:2]
    Hk, Wk = template.shape[:2]
    Ho = Hi - Hk + 1
    Wo = Wi - Wk + 1

    image_float = img.astype('float')
    template_float = template.astype('float')

    kernel_magnitude = np.linalg.norm(template_float)
    response = np.zeros((Ho, Wo))

    # GREYSCALE

    if len(img.shape) == 2:
        for i in range(Ho):
            for j in range(Wo):
                covered_elements =image_float[i:i+Hk, j:j+Wk]
                covered_magnitude = np.linalg.norm(covered_elements)
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = np.sum(template_float * covered_elements)
                response[i, j] = norm_coefficient * filtered_value

    # RGB
    elif len(img.shape) == 3:
        for i in range(Ho):
            for j in range(Wo):
                covered_elements =image_float[i:i + Hk, j:j + Wk, :]
                covered_magnitude = np.linalg.norm(covered_elements)
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = 0.0

                for ch in range(3):
                    neighbours = covered_elements[:, :, ch]
                    filtered_value += np.sum(template_float[:, :, ch] * neighbours)

                response[i, j] = norm_coefficient * filtered_value

    return response


def normalized_cross_correlation_matrix(img, template):

    Hi, Wi = img.shape[:2]
    Hk, Wk = template.shape[:2]
    Ho = Hi - Hk + 1
    Wo = Wi - Wk + 1

    image_float = img.astype('float')
    template_float = template.astype('float')

    kernel_magnitude = np.linalg.norm(template_float)
    num_channels = 3 if len(img.shape) == 3 else 1

    template_r = np.zeros((num_channels*Hk*Wk, 1))
    input_r = np.zeros((Ho*Wo, num_channels*Hk*Wk))
    reshape_column = 0

    #GREYSCALE
    if len(img.shape) == 2:
        template_r = [[h] for h in template.flatten()]

        for i in range(Hk):
            for j in range(Wk):
                input_r[:, reshape_column] =image_float[i:i+Ho, j:j+Wo].flatten()
                reshape_column += 1

    #RGB
    elif len(img.shape) == 3:
        template_r_len = Hk*Wk
        template_r[:template_r_len, 0] = template[:, :, 0].flatten()
        template_r[template_r_len:2 * template_r_len, 0] = template[:, :, 1].flatten()
        template_r[2 * template_r_len:, 0] = template[:, :, 2].flatten()

        for c in range(3):
            for i in range(Hk):
                for j in range(Wk):
                    input_r[:, reshape_column] =image_float[i:i + Ho, j:j + Wo, c].flatten()
                    reshape_column += 1

    ones_kernel = np.ones((num_channels * Hk * Wk, 1))
    input_squared = input_r ** 2
    cover_magnitude = np.sqrt(np.matmul(input_squared, ones_kernel))

    response_r = np.matmul(input_r, template_r)
    response_temp = (1 / (kernel_magnitude * cover_magnitude)) * response_r
    
    response = np.reshape(response_temp, (Ho, Wo))

    return response


##### Part 3: Non-maximum Suppression #####

def non_max_suppression(response, suppress_range, threshold=None):
   
    
    res = np.where(response < threshold, 0 , response) 
    height, width = res.shape[:2]
    H_range, W_range = suppress_range
    max_coord = []
    while (np.count_nonzero(res) > 0):
        global_max = np.max(res)
        max_location = np.where(res == global_max)
        max_location = (max_location[0][0], max_location[1][0])
        max_coord.append(max_location)

        H_low = max_location[0] - int(H_range/2)
        H_high = max_location[0] + int(H_range/2) 
        if H_low < 0 :
            H_low = 0
        if H_high >= height:
            H_high = height

        W_low = max_location[1] - int(W_range/2) 
        W_high = max_location[1] + int(W_range/2)
        if W_low < 0 :
                W_low = 0
        if W_high >= width:
            W_high = width
        res[H_low:H_high, W_low:W_high] = np.zeros((H_high - H_low, W_high - W_low))
    ###
    for i in max_coord:
        res[i[0],i[1]] = 1
    return res

##### Part 4: Question And Answer #####


def normalized_cross_correlation_ms(img, template):
   
    Hi, Wi = img.shape[:2]
    Hk, Wk = template.shape[:2]
    Ho = Hi - Hk + 1
    Wo = Wi - Wk + 1

    image_float = img.astype('float')
    template_float = template.astype('float')
    response = np.zeros((Ho, Wo))

    # GREYSCALE
    if len(img.shape) == 2:
        kernel_ms = template_float - np.mean(template_float)
        kernel_magnitude = np.linalg.norm(kernel_ms)

        for i in range(Ho):
            for j in range(Wo):
                covered_elements =image_float[i:i+Hk, j:j+Wk]
                covered_elements_ms = covered_elements - np.mean(covered_elements)
                covered_magnitude = np.linalg.norm(covered_elements_ms)
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = np.sum(kernel_ms * covered_elements_ms)
                response[i, j] = norm_coefficient * filtered_value

    #RGB
    elif len(img.shape) == 3:
        r_mean_1 = np.mean(template_float[:, :, 0])
        g_mean_1 = np.mean(template_float[:, :, 1])
        b_mean_1 = np.mean(template_float[:, :, 2])
        kernel_ms = template_float - [r_mean_1, g_mean_1, b_mean_1]
        kernel_magnitude = np.linalg.norm(kernel_ms)

        for i in range(Ho):
            for j in range(Wo):
                covered_elements =image_float[i:i+Hk, j:j+Wk, :]
                r_mean_2 = np.mean(covered_elements[:, :, 0]) 
                g_mean_2 = np.mean(covered_elements[:, :, 1])
                b_mean_2 = np.mean(covered_elements[:, :, 2])
                covered_elements_ms = covered_elements - [r_mean_2, g_mean_2, b_mean_2]
                covered_magnitude = math.sqrt(np.sum(covered_elements_ms**2))
                norm_coefficient = 1 / (kernel_magnitude * covered_magnitude)
                filtered_value = 0.0

                for ch in range(3):
                    neighbours = covered_elements_ms[:, :, ch]
                    filtered_value += np.sum(kernel_ms[:, :, ch] * neighbours)
               
                response[i, j] = norm_coefficient * filtered_value

    return response


"""Helper functions: You should not have to touch the following functions.
"""
def read_img(filename):
    '''
    Read HxWxC image from the given filename
    :return img: numpy.ndarray, size (H, W, C) for RGB. The value is between [0, 255].
    '''
    img = cv2.imread(filename)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img

def show_imgs(imgs, titles=None):
    '''
    Display a list of images in the notebook cell.
    :param imgs: a list of images or a single image
    '''
    if isinstance(imgs, list) and len(imgs) != 1:
        n = len(imgs)
        fig, axs = plt.subplots(1, n, figsize=(15,15))
        for i in range(n):
            axs[i].imshow(imgs[i], cmap='gray' if len(imgs[i].shape) == 2 else None)
            if titles is not None:
                axs[i].set_title(titles[i])
    else:
        img = imgs[0] if (isinstance(imgs, list) and len(imgs) == 1) else imgs
        plt.figure()
        plt.imshow(img, cmap='gray' if len(img.shape) == 2 else None)

def show_img_with_points(response, img_ori=None):
    '''
    Draw small red rectangles of size defined by rec_shape around the non-zero points in the image.
    Display the rectangles and the image with rectangles in the notebook cell.
    :param response: numpy.ndarray. The input response should be a very sparse image with most of points as 0.
                     The response map is from the non-maximum suppression.
    :param img_ori: numpy.ndarray. The original image where response is computed from
    :param rec_shape: a tuple of 2 ints. The size of the red rectangles.
    '''
    response = response.copy()
    if img_ori is not None:
        img_ori = img_ori.copy()

    xs, ys = response.nonzero()
    for x, y in zip(xs, ys):
        response = cv2.circle(response, (y, x), radius=0, color=(255, 0, 0), thickness=5)
        if img_ori is not None:
            img_ori = cv2.circle(img_ori, (y, x), radius=0, color=(255, 0, 0), thickness=5)
        
    if img_ori is not None:
        show_imgs([response, img_ori])
    else:
        show_imgs(response)


