import math
import numpy as np
import cv2 
import matplotlib.pyplot as plt
from matplotlib import cm


##################### TASK 1 ###################

# 1.1 IMPLEMENT
def make_gaussian_kernel(ksize, sigma):
    
    if ksize % 2 != 0:
        x_mean = y_mean = ksize // 2
    else:
        x_mean = y_mean = (ksize // 2) + 1    

    kernel = np.zeros((ksize, ksize))

    for x in range(ksize):
        for y in range(ksize):
            kernel[x][y] = np.exp(((x-x_mean)**2 + (y-y_mean)**2)/(-2*(sigma**2)))    

    return kernel / kernel.sum()

# GIVEN
def cs4243_filter(image, kernel):
    """
    Fast version of filtering algorithm.
    Pre-extract all the regions of kernel size,
    and obtain a matrix of shape (Hi*Wi, Hk*Wk), also reshape the flipped
    kernel to be of shape (Hk*Wk, 1), then do matrix multiplication, and reshape back
    to get the final output image. 
    :param image: numpy.ndarray
    :param kernel: numpy.ndarray
    :return filtered_image: numpy.ndarray
    """
    def cs4243_rotate180(kernel):
        kernel = np.flip(np.flip(kernel, 0),1)
        return kernel
    
    def img2col(input, h_out, w_out, h_k, w_k, stride):
        h, w = input.shape
        out = np.zeros((h_out*w_out, h_k*w_k))
        
        convwIdx = 0
        convhIdx = 0
        for k in range(h_out*w_out):
            if convwIdx + w_k > w:
                convwIdx = 0
                convhIdx += stride
            out[k] = input[convhIdx:convhIdx+h_k, convwIdx:convwIdx+w_k].flatten()
            convwIdx += stride
        return out
    
    Hi, Wi = image.shape
    Hk, Wk = kernel.shape
    if Hk % 2 == 0 or Wk % 2 == 0:
        raise ValueError
        
    hkmid = Hk//2
    wkmid = Wk//2

    image = cv2.copyMakeBorder(image, hkmid, hkmid, wkmid, wkmid, cv2.BORDER_REFLECT)
    filtered_image = np.zeros((Hi, Wi))
    kernel = cs4243_rotate180(kernel)
    col = img2col(image, Hi, Wi, Hk, Wk, 1)
    kernel_flatten = kernel.reshape(Hk*Wk, 1)
    output = col @ kernel_flatten 
    filtered_image = output.reshape(Hi, Wi)
    
    return filtered_image

# GIVEN
def cs4243_blur(img, gaussian_kernel, display=True):
    '''
    Performing Gaussian blurring on an image using a Gaussian kernel.
    :param img: input image
    :param gaussian_kernel: gaussian kernel
    :return blurred_img: blurred image
    '''

    blurred_img = cs4243_filter(img, gaussian_kernel)

    if display:

        fig1, axes_array = plt.subplots(1, 2)
        fig1.set_size_inches(8,4)
        image_plot = axes_array[0].imshow(img,cmap=plt.cm.gray) 
        axes_array[0].axis('off')
        axes_array[0].set(title='Original Image')
        image_plot = axes_array[1].imshow(blurred_img,cmap=plt.cm.gray)
        axes_array[1].axis('off')
        axes_array[1].set(title='Filtered Image')
        plt.show()  
    return blurred_img

# 2 IMPLEMENT
def estimate_gradients(original_img, display=True):
    
    dx = None
    dy = None
    d_mag = None
    d_angle = None
    
    Kx = np.array(
        [[-1,  -2, -1],
         [0,  0,  0],
         [1, 2, 1]]
    )

    Ky = np.array(
        [[-1,  0, 1],
         [-2,  0, 2],
         [-1,  0, 1]]
    )

    norm_img = original_img / 255
    dx = cs4243_filter(norm_img, Kx)
    dy = cs4243_filter(norm_img, Ky)

    d_mag = np.sqrt((dx**2) + (dy**2))
    d_mag = (d_mag/np.linalg.norm(d_mag))*255
    d_angle = np.arctan2(dy,dx)


    # END
    if display:
    
        fig2, axes_array = plt.subplots(1, 4)
        fig2.set_size_inches(16,4)
        image_plot = axes_array[0].imshow(d_mag, cmap='gray')  
        axes_array[0].axis('off')
        axes_array[0].set(title='Gradient Magnitude')

        image_plot = axes_array[1].imshow(dx, cmap='gray')  
        axes_array[1].axis('off')
        axes_array[1].set(title='dX')

        image_plot = axes_array[2].imshow(dy, cmap='gray')  
        axes_array[2].axis('off')
        axes_array[2].set(title='dY')

        image_plot = axes_array[3].imshow(d_angle, cmap='gray')  
        axes_array[3].axis('off')
        axes_array[3].set(title='Gradient Direction')
        plt.show()
    
    return d_mag, d_angle

# 3a IMPLEMENT
def non_maximum_suppression_interpol(d_mag, d_angle, display=True):
    
    out = np.zeros(d_mag.shape, d_mag.dtype)
    # Change angles to degrees to improve quality of life
    d_angle_180 = d_angle * 180/np.pi
    
    x_range, y_range = out.shape
    for x in range(1, x_range - 1):
        for y in range(1, y_range - 1):
            angle = d_angle_180[x][y]
            neighbour = d_mag[x][y]
            if -180 <= angle < -135 or 0 <= angle <= 45:
                value = np.tan((angle/180) * np.pi) if angle > 0 else - np.tan((angle/180) * np.pi)
                neighbour1 = value * (d_mag[x + 1][y + 1] - d_mag[x + 1][y]) + d_mag[x + 1][y]
                neighbour2 = value * (d_mag[x - 1][y - 1] - d_mag[x - 1][y]) + d_mag[x - 1][y]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            elif 45 < angle <= 90 or -135 <= angle < -90:
                angle = 90 - angle if angle > 0 else 90 + angle
                value = np.tan((angle/180) * np.pi) if angle > 0 else - np.tan((angle/180) * np.pi)
                neighbour1 = value * (d_mag[x + 1][y + 1] - d_mag[x][y + 1]) + d_mag[x][y + 1]
                neighbour2 = value * (d_mag[x - 1][y - 1] - d_mag[x][y - 1]) + d_mag[x][y - 1]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            elif -90 <= angle < -45 or 90 < angle <= 135:
                angle = angle - 90 if angle > 0 else 90 + angle
                value = np.tan((angle/180) * np.pi) if angle > 0 else - np.tan((angle/180) * np.pi)
                neighbour1 = value * (d_mag[x + 1][y - 1] - d_mag[x][y + 1]) + d_mag[x][y + 1]
                neighbour2 = value * (d_mag[x - 1][y + 1] - d_mag[x][y - 1]) + d_mag[x][y - 1]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            elif 135 < angle <= 180 or -45 <= angle < 0:
                angle = 180 - angle if angle > 0 else angle
                value = np.tan((angle/180) * np.pi) if angle > 0 else - np.tan((angle/180) * np.pi)
                neighbour1 = value * (d_mag[x - 1][y + 1] - d_mag[x - 1][y]) + d_mag[x - 1][y]
                neighbour2 = value * (d_mag[x + 1][y - 1] - d_mag[x + 1][y]) + d_mag[x + 1][y]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour



    # END
    if display:
        _ = plt.figure(figsize=(10,10))
        plt.imshow(out, cmap='gray')
        plt.title("Suppressed image (with interpolation)")
    
    return out

# 3b IMPLEMENT
def non_maximum_suppression(d_mag, d_angle, display=True):
    
    out = np.zeros(d_mag.shape, d_mag.dtype)
    # Change angles to degrees to improve quality of life
    d_angle_180 = d_angle * 180/np.pi
 
    x_range, y_range = out.shape
    for x in range(1, x_range - 1):
        for y in range(1, y_range - 1):
            angle = d_angle_180[x][y]
            neighbour = d_mag[x][y]
            if -22.5 <= angle < 22.5 or 157.5 <= angle <= 180 or -180 <= angle < -157.5:
                neighbour1 = d_mag[x + 1][y]
                neighbour2 = d_mag[x - 1][y]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            elif 112.5 <= angle < 157.5 or -67.5 <= angle < -22.5:
                neighbour1 = d_mag[x + 1][y - 1]
                neighbour2 = d_mag[x - 1][y + 1]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            elif  -67.5 <= angle < -22.5 or -112.5 <= angle < -67.5:
                neighbour1 = d_mag[x][y + 1]
                neighbour2 = d_mag[x][y - 1]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour
            else: 
                neighbour1 = d_mag[x + 1][y + 1]
                neighbour2 = d_mag[x - 1][y - 1]
                if neighbour > neighbour1 and neighbour > neighbour2:
                    out[x][y] = neighbour

    # END
    if display:
        _ = plt.figure(figsize=(10,10))
        plt.imshow(out)
        plt.title("Suppressed image (without interpolation)")
    
    return out



# 4 IMPLEMENT
def double_thresholding(inp, perc_weak=0.1, perc_strong=0.3, display=True):
    
    weak_edges = strong_edges = None
    
    min_val, max_val = np.min(inp), np.max(inp)
    range = max_val - min_val
    high_threshold = min_val + perc_strong * range 
    low_threshold = min_val + perc_weak * range

    strong_edges = np.where(inp > high_threshold, 1, 0)
    weak_edges = np.where(low_threshold < inp, 1, 0)
    weak_edges = weak_edges - strong_edges
    weak_edges = np.where(weak_edges >= 0, weak_edges, 0)

    if display:

        fig2, axes_array = plt.subplots(1, 2)
        fig2.set_size_inches(10,5)
        image_plot = axes_array[0].imshow(strong_edges, cmap='gray')  
        axes_array[0].axis('off')
        axes_array[0].set(title='Strong ')

        image_plot = axes_array[1].imshow(weak_edges, cmap='gray')  
        axes_array[1].axis('off')
        axes_array[1].set(title='Weak')
        
    return weak_edges, strong_edges

# 5 IMPLEMENT
def edge_linking(weak, strong, n=200, display=True):
 
    assert weak.shape == strong.shape, \
        "Weak and strong edge image have to have the same dimension"
    out = None
    
    x_limit, y_limit = strong.shape
    for iter in range(n):
        check = False

        x_i, y_i = np.where(strong == 1)

        for ind in zip(x_i, y_i):
            neighbors = [(ind[0], ind[1] + 1), (ind[0] + 1, ind[1]), (ind[0] + 1, ind[1] + 1), (ind[0], ind[1] - 1), (ind[0] - 1, ind[1]), (ind[0] - 1, ind[1] - 1) ,
            (ind[0] - 1, ind[1] + 1), (ind[0] + 1, ind[1] - 1)]

            for neighbour_index in neighbors:
                if 0 <= neighbour_index[0] < x_limit and 0 <= neighbour_index[1] < y_limit:
                    if weak[neighbour_index[0]][neighbour_index[1]] == 1:
                        added = True
                        strong[neighbour_index[0]][neighbour_index[1]] = 1
                        weak[neighbour_index[0]][neighbour_index[1]] = 0
        if not check:
            break
    out = strong    

    if display:
        _ = plt.figure(figsize=(10,10))
        plt.imshow(out)
        plt.title("Edge image")
    return out

##################### TASK 2 ######################

# 1/2/3 IMPLEMENT
def hough_vote_lines(img):
    
    distance_interval = 1
    theta_interval = math.pi/180
    img_height, img_width = img.shape
    dist_max = math.sqrt(img_height**2 + img_width**2)
    dist_min = -dist_max
    theta_max = math.pi
    theta_min = 0

    
    dist_bin_num = math.ceil((dist_max - dist_min) / distance_interval)
    theta_bin_num = math.ceil((theta_max - theta_min) / theta_interval)
    A = np.zeros((dist_bin_num, theta_bin_num), int)
    
    distance = np.arange(dist_min, dist_max, distance_interval)
    theta = np.arange(theta_min, theta_max, theta_interval)
    
    
    for x in range(img_height):
        for y in range(img_width):
            if img[x][y] <= 0:
                continue
            for i in range(len(theta)):
                s = theta[i]
                dist = x * np.cos(s) + y * np.sin(s)
               
                j = np.argmax(distance > dist) - 1
                A[j, i] += 1
                
            
    return A, distance, theta

# 4 GIVEN
from skimage.feature import peak_local_max
def find_peak_params(hspace, params_list,  window_size=1, threshold=0.5):
    '''
    Given a Hough space and a list of parameters range, compute the local peaks
    aka bins whose count is larger max_bin * threshold. The local peaks are computed
    over a space of size (2*window_size+1)^(number of parameters).

    Also include the array of values corresponding to the bins, in descending order.
    
    e.g.
    Suppose for a line detection case, you get the following output:
    [
    [122, 101, 93],
    [3,   40,  21],
    [0,   1.603, 1.605]
    ]
    This means that the local maxima with the highest vote gets a vote score of 122, and the corresponding parameter value is distance=3, 
    theta = 0.
    '''
    assert len(hspace.shape) == len(params_list), \
        "The Hough space dimension does not match the number of parameters"
    for i in range(len(params_list)):
        assert hspace.shape[i] == len(params_list[i]), \
            f"Parameter length does not match size of the corresponding dimension:{len(params_list[i])} vs {hspace.shape[i]}"
    peaks_indices = peak_local_max(hspace.copy(), exclude_border=False, threshold_rel=threshold, min_distance=window_size)
    peak_values = np.array([hspace[tuple(peaks_indices[j])] for j in range(len(peaks_indices))])
    res = []
    res.append(peak_values)
    for i in range(len(params_list)):
        res.append(params_list[i][peaks_indices.T[i]])
    return res


##################### TASK 3 ######################

# 1/2/3 IMPLEMENT
from skimage.draw import circle_perimeter
def hough_vote_circles(img, radius = None):
    
    # neighbour the radius range
    h, w = img.shape[:2]    
    if radius == None:
        r_max = np.hypot(h,w)
        r_min = 3
    else:
        [r_min,r_max] = radius
    
    r_interval = 1
    a_interval = 1
    b_interval = 1
    img_height, img_width = img.shape
    a_max = img_height
    b_max = img_width

    
    r_bin_num = math.ceil((r_max - r_min) / r_interval)
    a_bin_num = math.ceil(a_max / a_interval)
    b_bin_num = math.ceil(b_max / b_interval)
    A = np.zeros((r_bin_num, a_bin_num, b_bin_num))
    
    r = np.arange(r_min, r_max, r_interval)
    X = np.arange(0, a_max, a_interval)
    Y = np.arange(0, b_max, b_interval)

    r_weighted = np.linspace(1, 1 + ((r_max - r_min) / r_min), r_bin_num)[::-1]
    
    for x in range(img_height):
        for y in range(img_width):
            if img[x][y] <= 0:
                continue

            for i in range(len(r)):
                R = r[i]
                perimeter_x, perimeter_y = circle_perimeter(x, y, R, shape=(img.shape)) 
                if  a_interval == 1 and b_interval == 1 and r_interval == 1:
                    A[i, perimeter_x, perimeter_y] += r_weighted[i]                
                else:
                    for n in range(len(perimeter_x)):
                        j = np.argmax(X > perimeter_x[n]) - 1
                        k = np.argmax(Y > perimeter_y[n]) - 1
                        if j < 0 or k < 0:
                            continue
                        A[i, j, k] += r_weighted[i]
   
    return A, r, X, Y

##################### TASK 4 ######################

# IMPLEMENT
def hough_vote_circles_grad(img, d_angle, radius = None):
    
    # neighbour the radius range
    h, w = img.shape[:2]    
    if radius == None:
        R_max = np.hypot(h,w)
        R_min = 3
    else:
        [R_min,R_max] = radius
    
    R_interval = 10
    a_interval = 10
    b_interval = 10
    img_height, img_width = img.shape
    a_max = img_height
    b_max = img_width

    
    R_bin_num = math.ceil((R_max - R_min) / R_interval)
    a_bin_num = math.ceil(a_max / a_interval)
    b_bin_num = math.ceil(b_max / b_interval)
    A = np.zeros((R_bin_num, a_bin_num, b_bin_num))
    
    R = np.arange(R_min, R_max, R_interval)
    X = np.arange(0, a_max, a_interval)
    Y = np.arange(0, b_max, b_interval)

    
    R_weighted_incr = np.ones((R_bin_num))
    
    
    for x in range(img_height):
        for y in range(img_width):
            if img[x][y] <= 0:
                continue

            for i in range(len(R)):
                r = R[i]
                theta = d_angle[x, y]
                a1 = round(x + r * np.cos(theta))
                b1 = round(y + r * np.sin(theta))
                a2 = round(x - r * np.cos(theta))
                b2 = round(x - r * np.sin(theta))
                
                if R_interval == 1 and a_interval == 1 and b_interval == 1:
                    if (a1 < img_height and a1 >= 0) and (b1 < img_height and b1 >= 0):
                        A[i, a1, b1] += R_weighted_incr[i]
                    if (a2 < img_height and a2 >= 0) and (b2 < img_height and b2 >= 0):
                        A[i, a2, b2] += R_weighted_incr[i]

                
                else:
                    
                    j1 = np.argmax(X > a1) - 1
                    k1 = np.argmax(Y > b1) - 1
                    j2 = np.argmax(X > a2) - 1
                    k2 = np.argmax(Y > b2) - 1
                    if (j1 < img_height and j1 >= 0) and (k1 < img_height and k1 >= 0):
                        A[i, j1, k1] += R_weighted_incr[i]
                    if (j2 < img_height and j2 >= 0) and (k2 < img_height and k2 >= 0):
                        A[i, j2, k2] += R_weighted_incr[i]


    # END
    return A, R, X, Y

###############################################
"""Helper functions: You should not have to touch the following functions.
"""
def read_img(filename):
    '''
    Read HxWxC image from the given filename
    :return img: numpy.ndarray, size (H, W, C) for RGB. The value is between [0, 255].
    '''
    img = cv2.imread(filename)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    return img

def draw_lines(hspace, dists, thetas, hs_maxima, file_path):
    im_c = read_img(file_path)
    fig, axes = plt.subplots(1, 3, figsize=(15, 6))
    ax = axes.ravel()

    ax[0].imshow(im_c, cmap=cm.gray)
    ax[0].set_title('Input image')
    ax[0].set_axis_off()

    angle_step = 0.5 * np.diff(thetas).mean()
    d_step = 0.5 * np.diff(dists).mean()
    bounds = [np.rad2deg(thetas[0] - angle_step),
              np.rad2deg(thetas[-1] + angle_step),
              dists[-1] + d_step, dists[0] - d_step]

    ax[1].imshow(np.log(1 + hspace), extent=bounds, cmap=cm.gray, aspect=1 / 1.5)
    ax[1].set_title('Hough transform')
    ax[1].set_xlabel('Angles (degrees)')
    ax[1].set_ylabel('Distance (pixels)')
    ax[1].axis('image')

    ax[2].imshow(im_c, cmap=cm.gray)
    ax[2].set_ylim((im_c.shape[0], 0))
    ax[2].set_axis_off()
    ax[2].set_title('Detected lines')

    # You may want to change the codes below if you use a different axis choice.
    for _, dist, angle in zip(*hs_maxima):
        (x0, y0) = dist * np.array([np.cos(angle), np.sin(angle)])
        ax[2].axline((y0, x0), slope=np.tan(np.pi-angle))

    plt.tight_layout()
    plt.show()

def draw_circles(local_maxima, file_path, title):
    # If this function does not work, use the other version (v2) below.
    img = cv2.imread(file_path)
    fig = plt.figure(figsize=(7,7))
    plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    circle = []
    for _,r,x,y in zip(*local_maxima):
        circle.append(plt.Circle((y,x),r,color=(1,0,0),fill=False))
        fig.add_subplot(111).add_artist(circle[-1])
    plt.title(title)    
    plt.show()

from matplotlib.patches import Circle
def draw_circles_v2(local_maxima, file_path, title):
    img = cv2.imread(file_path)
    plt.rcParams["figure.figsize"] = [7.0, 7.0]
    fig, ax = plt.subplots(1)
    ax.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    circle = []
    for _,r,x,y in zip(*local_maxima):
         ax.add_patch(Circle((y, x), r, color='red', fill=False))
    plt.title(title)    
    plt.show()